let num = prompt('Write number');

if (num[0] == num[5] && num[1] == num[4] && num[2] == num[3]) {
    alert('число зеркальное');
}  else {
    alert('число не зеркальное');
}



