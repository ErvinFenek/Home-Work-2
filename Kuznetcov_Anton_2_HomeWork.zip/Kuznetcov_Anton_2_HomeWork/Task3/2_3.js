

let num1 = parseInt(prompt('Write first number'));
let num2 = parseInt(prompt('Write first number'));
let num3 = parseInt(prompt('Write first number'));



if (num1 > num2 && num1 > num3 ) {
    alert(num1 + ' первое число больше всех остальных');
}  else if (num2 > num1 && num2 > num3 ) {
    alert(num2 + ' второе число больше всех остальных');
} else if (num3 > num1 && num3 > num2 ) {
    alert(num3 + ' третье число больше всех остальных');
} else if (num1 == num2 && num3 == num2 ) {
    alert('все числа одинаковые');
}