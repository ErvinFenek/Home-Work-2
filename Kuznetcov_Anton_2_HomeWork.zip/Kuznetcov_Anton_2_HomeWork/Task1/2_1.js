
let num = prompt('Write number')

if (num[0] == num[1] && num[1] == num[2] ) {
    alert('все цифри одинаковые');
}  else if (num[0] == num[1] || num[1] == num[2] || num[0] == num[2]) {
    alert('две цифры одинаковые');
} else  {
    alert('все цифри неодинаковые');
}