

let login = prompt('Write login');
if (login === 'admin') {
    let password = prompt('Write password')
    if (password === 'mySuperPassword') {
        alert('all right, please wait')
    } else {
        alert('good luck, try again')
    }
} else {
    alert('good luck, try again')
}

